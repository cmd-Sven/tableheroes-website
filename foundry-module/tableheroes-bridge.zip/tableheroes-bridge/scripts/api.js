const MODULE_ID = "tableheroes-bridge";

function normalizeFoundryActorId(raw) {
  const trimmed = String(raw ?? "").trim();
  if (!trimmed) return trimmed;
  return trimmed.startsWith("Actor.") ? trimmed : `Actor.${trimmed}`;
}

export function getModuleSettings() {
  const baseUrl = String(game.settings.get(MODULE_ID, "apiBaseUrl") ?? "").replace(/\/$/, "");
  const apiKey = String(game.settings.get(MODULE_ID, "apiKey") ?? "").trim();
  const refreshMinutes = Number(game.settings.get(MODULE_ID, "refreshMinutes") ?? 5);
  return {
    baseUrl,
    apiKey,
    refreshMinutes: Number.isFinite(refreshMinutes) ? Math.max(1, refreshMinutes) : 5,
  };
}

export function settingsConfigured() {
  const { baseUrl, apiKey } = getModuleSettings();
  return Boolean(baseUrl && apiKey);
}

function apiHeaders(includeJson = true) {
  const { apiKey } = getModuleSettings();
  const headers = { "x-tableheroes-api-key": apiKey };
  if (includeJson) headers["Content-Type"] = "application/json";
  return headers;
}

/**
 * @param {string} foundryActorId
 * @returns {Promise<object>}
 */
export async function fetchActorProfile(foundryActorId) {
  const actorId = normalizeFoundryActorId(foundryActorId);
  const { baseUrl, apiKey } = getModuleSettings();
  if (!baseUrl || !apiKey) {
    throw new Error("Table Heroes API ist nicht konfiguriert.");
  }

  if (/tableheroes\.de/i.test(baseUrl) && !/table-heroes\.de/i.test(baseUrl)) {
    throw new Error("API-URL muss https://table-heroes.de sein (mit Bindestrich).");
  }

  const url = new URL(`${baseUrl}/api/v1/foundry-sync/profile`);
  url.searchParams.set("foundry_actor_id", actorId);
  url.searchParams.set("achievements_limit", "8");
  url.searchParams.set("points_log_limit", "5");

  console.log("[tableheroes-bridge] GET", url.toString());

  const response = await fetch(url.toString(), {
    method: "GET",
    headers: { "x-tableheroes-api-key": apiKey },
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(data.error || `HTTP ${response.status}`);
  }

  let player = null;
  if (Array.isArray(data.players)) {
    player = data.players.find((entry) => entry?.mapped && entry?.points) ?? data.players[0] ?? null;
  }
  if (!player) {
    console.warn("[tableheroes-bridge] leere players-Antwort für", actorId, data);
    player = {
      foundry_actor_id: actorId,
      character_id: null,
      character_name: null,
      user_id: null,
      username: null,
      mapped: false,
      points: null,
      achievements: [],
      recent_points: [],
      wealth: null,
      portrait: null,
    };
  }

  return {
    campaign: {
      id: data.campaign_id,
      name: data.campaign_name,
      dashboard_url: data.dashboard_url,
      points_catalog_url: data.points_catalog_url,
    },
    player,
  };
}

/**
 * @param {Actor} actor
 * @param {"foundry_to_th" | "th_to_foundry"} direction
 */
export async function syncActorWealth(actor, direction) {
  const { baseUrl } = getModuleSettings();
  if (!baseUrl) throw new Error("Table Heroes API ist nicht konfiguriert.");

  const currency = readFoundryCurrency(actor);
  const actorId = normalizeFoundryActorId(actor.id);
  const body =
    direction === "foundry_to_th"
      ? { foundry_actor_id: actorId, direction, currency }
      : { foundry_actor_id: actorId, direction };

  const response = await fetch(`${baseUrl}/api/v1/foundry-sync/wealth`, {
    method: "POST",
    headers: apiHeaders(),
    body: JSON.stringify(body),
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(data.error || data.message || `HTTP ${response.status}`);
  }

  if (direction === "th_to_foundry" && data.currency) {
    await applyFoundryCurrency(actor, data.currency);
  }

  return data;
}

/**
 * @param {Actor} actor
 * @param {"foundry_to_th" | "th_to_foundry"} direction
 */
export async function syncActorPortrait(actor, direction) {
  const { baseUrl } = getModuleSettings();
  if (!baseUrl) throw new Error("Table Heroes API ist nicht konfiguriert.");

  if (direction === "th_to_foundry") {
    const response = await fetch(`${baseUrl}/api/v1/foundry-sync/portrait`, {
      method: "POST",
      headers: apiHeaders(),
      body: JSON.stringify({ foundry_actor_id: normalizeFoundryActorId(actor.id), direction }),
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      throw new Error(data.error || data.message || `HTTP ${response.status}`);
    }
    if (data.portrait?.url) {
      await actor.update({ img: data.portrait.url });
    }
    return data;
  }

  const img = actor.img;
  if (!img) throw new Error("Foundry-Actor hat kein Portrait.");

  const imageResponse = await fetch(img);
  if (!imageResponse.ok) {
    throw new Error("Foundry-Portrait konnte nicht gelesen werden.");
  }

  const blob = await imageResponse.blob();
  const form = new FormData();
  form.append("foundry_actor_id", normalizeFoundryActorId(actor.id));
  form.append("portrait", blob, "portrait.webp");

  const response = await fetch(`${baseUrl}/api/v1/foundry-sync/portrait`, {
    method: "POST",
    headers: { "x-tableheroes-api-key": getModuleSettings().apiKey },
    body: form,
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(data.error || data.message || `HTTP ${response.status}`);
  }
  return data;
}

/**
 * @param {Actor} actor
 */
function isProbablyFoundryId(value) {
  const trimmed = String(value ?? "").trim();
  if (!trimmed || trimmed.includes(" ")) return false;
  return /^[A-Za-z0-9]{12,24}$/.test(trimmed);
}

function sanitizeActorLabel(value) {
  const trimmed = String(value ?? "").trim();
  if (!trimmed || isProbablyFoundryId(trimmed)) return null;
  return trimmed;
}

function resolveActorClassName(actor) {
  const details = actor.system?.details ?? {};
  const resolved = sanitizeActorLabel(details.classResolved);
  if (resolved) return resolved;

  for (const item of actor.items ?? []) {
    if (String(item.type ?? "").toLowerCase() === "class") {
      const name = sanitizeActorLabel(item.name);
      if (name) return name;
    }
  }

  const cls = details.class;
  if (cls && typeof cls === "object") {
    const fromName = sanitizeActorLabel(cls.name ?? cls.label);
    if (fromName) return fromName;
    const fromValue = sanitizeActorLabel(cls.value);
    if (fromValue) return fromValue;
  }

  const asString = sanitizeActorLabel(typeof cls === "string" ? cls : null);
  return asString ?? "Unbekannt";
}

function resolveActorRaceName(actor) {
  const details = actor.system?.details ?? {};
  const resolved = sanitizeActorLabel(details.raceResolved);
  if (resolved) return resolved;

  const raceTypes = new Set(["race", "species", "ancestry"]);
  for (const item of actor.items ?? []) {
    if (raceTypes.has(String(item.type ?? "").toLowerCase())) {
      const name = sanitizeActorLabel(item.name);
      if (name) return name;
    }
  }

  const raceRef = details.race ?? details.species;
  if (raceRef && typeof raceRef === "object") {
    const fromName = sanitizeActorLabel(raceRef.name ?? raceRef.label);
    if (fromName) return fromName;
  }

  return sanitizeActorLabel(typeof raceRef === "string" ? raceRef : null);
}

export async function syncActorXp(actor) {
  const { baseUrl } = getModuleSettings();
  if (!baseUrl) throw new Error("Table Heroes API ist nicht konfiguriert.");

  const details = actor.system?.details ?? {};
  const cls = resolveActorClassName(actor);
  const race = resolveActorRaceName(actor);
  const level = Number(details.level ?? actor.system?.details?.level?.value ?? 0);
  const xp = Number(actor.system?.details?.xp?.value ?? actor.system?.details?.xp ?? 0);

  const response = await fetch(`${baseUrl}/api/v1/foundry-sync`, {
    method: "POST",
    headers: apiHeaders(),
    body: JSON.stringify({
      foundry_actor_id: normalizeFoundryActorId(actor.id),
      class: cls,
      race: race ?? undefined,
      level: Math.max(0, Math.floor(level)),
      experience_points: Math.max(0, Math.floor(xp)),
    }),
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok && response.status !== 202) {
    throw new Error(data.error || data.message || `HTTP ${response.status}`);
  }
  if (response.status === 202) {
    throw new Error(data.message || "Actor ist noch nicht zugeordnet.");
  }
  return data;
}

/**
 * Serialisiert actor.system inkl. berechneter Kampfwerte (AC, TP, Initiative).
 * @param {Actor} actor
 */
function buildActorSystemPayload(actor) {
  const sys = actor.system ?? {};
  let base = {};
  try {
    base = typeof sys.toObject === "function" ? foundry.utils.duplicate(sys.toObject()) : foundry.utils.duplicate(sys);
  } catch {
    base = { ...sys };
  }

  base.attributes = base.attributes ?? {};
  base.attributes.ac = { ...(base.attributes.ac ?? {}) };
  base.attributes.hp = { ...(base.attributes.hp ?? {}) };
  base.attributes.init = { ...(base.attributes.init ?? {}) };

  const acValue = Number(sys?.attributes?.ac?.value);
  if (Number.isFinite(acValue) && acValue > 0) {
    base.attributes.ac.value = acValue;
  }

  const hpMax = Number(sys?.attributes?.hp?.max);
  const hpValue = Number(sys?.attributes?.hp?.value);
  if (Number.isFinite(hpMax) && hpMax > 0) {
    base.attributes.hp.max = hpMax;
  }
  if (Number.isFinite(hpValue)) {
    base.attributes.hp.value = hpValue;
  }

  const initBonus = sys?.attributes?.init?.bonus;
  const initTotal = sys?.attributes?.init?.total;
  if (initBonus != null) base.attributes.init.bonus = initBonus;
  if (initTotal != null) base.attributes.init.total = initTotal;

  base.details = { ...(base.details ?? {}) };
  let totalLevels = 0;
  const raceTypes = new Set(["race", "species", "ancestry"]);
  for (const item of actor.items ?? []) {
    const type = String(item.type ?? "").toLowerCase();
    const name = String(item.name ?? "").trim();
    if (!name) continue;
    if (raceTypes.has(type)) base.details.raceResolved = name;
    if (type === "background") base.details.backgroundResolved = name;
    if (type === "class") {
      if (!base.details.classResolved) base.details.classResolved = name;
      totalLevels += Math.max(0, Math.floor(Number(item.system?.levels) || 0));
    }
  }
  if (totalLevels > 0) base.details.totalLevels = totalLevels;

  return base;
}

/**
 * Stammdaten-Items (Klasse, Volk, Hintergrund, Feats) müssen immer mitgesendet werden.
 * @param {Actor} actor
 */
function serializeActorItems(actor) {
  const identityTypes = new Set(["class", "subclass", "race", "species", "ancestry", "background", "feat"]);
  const serialized = [];
  const seen = new Set();

  const pushItem = (item) => {
    if (!item) return;
    try {
      const row = typeof item.toObject === "function" ? item.toObject() : item;
      const id = String(row._id ?? row.id ?? "");
      if (id && seen.has(id)) return;
      if (id) seen.add(id);
      serialized.push(row);
    } catch {
      serialized.push({ name: item.name, type: item.type, _id: item.id });
    }
  };

  for (const item of actor.items ?? []) {
    const type = String(item.type ?? "").toLowerCase();
    if (identityTypes.has(type)) pushItem(item);
  }
  for (const item of actor.items ?? []) {
    pushItem(item);
  }

  return serialized;
}

/**
 * Vollständiges DnD5e-Charakterblatt Foundry → Table Heroes (nur diese Richtung).
 * @param {Actor} actor
 */
export async function syncActorSheet(actor) {
  const { baseUrl } = getModuleSettings();
  if (!baseUrl) throw new Error("Table Heroes API ist nicht konfiguriert.");

  const items = serializeActorItems(actor);

  const response = await fetch(`${baseUrl}/api/v1/foundry-sync/sheet`, {
    method: "POST",
    headers: apiHeaders(),
    body: JSON.stringify({
      foundry_actor_id: normalizeFoundryActorId(actor.id),
      actor_name: String(actor.name ?? ""),
      actor_system: buildActorSystemPayload(actor),
      actor_items: items,
    }),
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok && response.status !== 202) {
    throw new Error(data.error || data.message || `HTTP ${response.status}`);
  }
  if (response.status === 202) {
    throw new Error(data.message || "Actor ist noch nicht zugeordnet.");
  }
  return data;
}

/**
 * @param {Actor} actor
 */
export function readFoundryCurrency(actor) {
  const c = actor.system?.currency ?? {};
  return {
    gp: Math.max(0, Math.floor(Number(c.gp) || 0)),
    sp: Math.max(0, Math.floor(Number(c.sp) || 0)),
    cp: Math.max(0, Math.floor(Number(c.cp) || 0)),
    ep: Math.max(0, Math.floor(Number(c.ep) || 0)),
    pp: Math.max(0, Math.floor(Number(c.pp) || 0)),
  };
}

/**
 * @param {Actor} actor
 * @param {{ gp: number, sp: number, cp: number, ep: number, pp: number }} currency
 */
export async function applyFoundryCurrency(actor, currency) {
  const next = {
    gp: Math.max(0, Math.floor(Number(currency.gp) || 0)),
    sp: Math.max(0, Math.floor(Number(currency.sp) || 0)),
    cp: Math.max(0, Math.floor(Number(currency.cp) || 0)),
    ep: Math.max(0, Math.floor(Number(currency.ep) || 0)),
    pp: Math.max(0, Math.floor(Number(currency.pp) || 0)),
  };
  await actor.update({ "system.currency": next });
}

/**
 * Liefert den Gäste-Join-Link zur laufenden Live-Session der Kampagne (neuer Browser-Tab).
 * @returns {Promise<{ live: boolean, join_url?: string, session_title?: string, message?: string }>}
 */
export async function fetchLiveSessionJoinUrl() {
  const { baseUrl, apiKey } = getModuleSettings();
  if (!baseUrl || !apiKey) {
    throw new Error("Table Heroes API ist nicht konfiguriert.");
  }

  const response = await fetch(`${baseUrl}/api/v1/foundry-sync/live-session`, {
    method: "GET",
    headers: apiHeaders(false),
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(data.error || `Live-Session API Fehler (${response.status})`);
  }
  return data;
}
